<?php
	$installer = new Installer;
?>
<p class="text-center">
  Chỉ vài bước đơn giản để cài đặt Web Builder
</p>
<p class="text-center">
  <a href="<?php $installer->nextUrl(); ?>" class="button">
    <?php $installer->nextText(); ?>
    <i class="fa fa-angle-right fa-fw" aria-hidden="true"></i>
  </a>
</p>